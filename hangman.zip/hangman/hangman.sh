#!/bin/sh
python hangman.py
